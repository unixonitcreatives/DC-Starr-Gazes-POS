    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="https://www.unixondev.com">Unixon IT Creatives</a>.</strong> All rights
    reserved.