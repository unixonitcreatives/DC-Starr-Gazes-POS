  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>DC</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>DC Starr Gazes</b> IMS</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
          
          </li>

          <li class="dropdown user user-menu">
            <a href="#" class="icon-bar" data-toggle="modal" data-target="#modal-default">
              <span class="hidden-xs">Log out</span> 
            </a>
          </li>

        </ul>
      </div>
    </nav>
  </header>

  <div class="modal modal-default fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Log out</h4>
              </div>
              <div class="modal-body">
                <p>Are you sure you want to log-out your account?</p>
              </div>
              <div class="modal-footer">
                <a href="login.php" class="btn btn-default btn" data-dismiss="modal">No</a>
                <a href="login.php" class="btn btn-danger btn">Yes</a>
                
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
    </div>
